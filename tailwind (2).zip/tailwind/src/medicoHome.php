<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>html</title>
   <link rel="stylesheet" href="output.css">
   <script src="https://cdn.tailwindcss.com"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
   
</head>
<style>
     .Green
   {
      color: green;
   }
   .disabled-input {
      pointer-events: none;
      background-color: #e5e7eb; /* gray-300 */
    }
</style>
<body class="min-h-screen min-w-full flex justify-items-center ">
   <div class="w-full bg-gray-200">
   
      <?php
      session_start();
      $user = isset($_SESSION['user']) ? $_SESSION['user'] : null;
      ?>
      
      <nav class="h-[3rem] w-full flex items-center justify-between bg-white shadow-md fixed px-4 md:px-10 z-50">
          
          <div class="flex items-center gap-3">
              <div class="text-2xl font-bold text-blue-500">MEDICO</div>
              <div class="w-10 h-10 bg-[url(medico.jpg)] bg-cover rounded-full"></div>
          </div>
      
          <div class="hidden md:flex gap-6 text-[15px] font-bold">
              <a href="medicine.html" class="hover:text-blue-500">MEDICINES</a>
              <a href="lab-tests.html" class="hover:text-blue-500">LAB TESTS</a>
              <a href="doctor.html" class="hover:text-blue-500">DOCTORS</a>
          </div>
      
          <div class="hidden md:flex items-center gap-4 text-sm font-semibold">
              <a href="offers.html" class="hover:text-blue-500">Offers</a>
      
              <?php if ($user): ?>
                  <div class="flex items-center gap-2 text-blue-600">
                      <span><?php echo htmlspecialchars($user['full_name']); ?></span>
                      <span>|</span>
                      <a href="pages/logout.php" class="hover:text-red-600">Logout</a>
                  </div>
              <?php else: ?>
                  <div class="flex gap-2">
                      <a href="pages/login.php" class="hover:text-blue-500">Login</a>
                      <span>|</span>
                      <a href="pages/signup.php" class="hover:text-blue-500">Sign Up</a>
                  </div>
              <?php endif; ?>
      
              <a href="need-help.html" class="hover:text-blue-500">Need Help?</a>
          </div>
      
          <div class="md:hidden">
              <button class="text-2xl focus:outline-none">&#9776;</button>
          </div>
      </nav>
      
  

      <div class="flex flex-col items-center">
   
      <div class="h-[3.5rem] w-full flex mt-[3rem] flex-wrap items-center justify-center md:justify-between bg-white px-4 py-2 gap-2">

<!-- Location Input with Icon and Clear Button -->
<div class="relative w-full md:w-[15rem] mb-2 md:mb-0">
  
  <!-- Location Icon (Adjusted left spacing) -->
  <svg xmlns="http://www.w3.org/2000/svg" fill="none"
       viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
       class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600 pointer-events-none">
    <path stroke-linecap="round" stroke-linejoin="round"
          d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
    <path stroke-linecap="round" stroke-linejoin="round"
          d="M19.5 10.5c0 7.5-7.5 11.25-7.5 11.25S4.5 18 4.5 10.5a7.5 7.5 0 1115 0z" />
  </svg>

  <!-- Clear Button -->
  <button onclick="clearLocation()" id="clear-btn"
          class="absolute right-3 top-1/2 -translate-y-1/2 text-purple-500 hover:text-red-600 hidden text-lg font-bold">
    ✖
  </button>

  <!-- Input Field (Fixed padding) -->
  <input id="location-input"
         onclick="getLocationOnce()"
         readonly
         placeholder="Detect Location"
         class="pl-10 pr-10 h-[2.25rem] w-full bg-gray-300 text-black px-2 rounded-md cursor-pointer"
         data-clicked="false">
</div>

<!-- Search Input -->
<div class="flex items-center gap-2 w-full md:w-[30rem] relative">
  <svg xmlns="http://www.w3.org/2000/svg" 
       class="w-5 h-5 text-gray-600 absolute left-2 top-1/2 transform -translate-y-1/2" 
       fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
          d="M21 21l-4.35-4.35M10 18a8 8 0 100-16 8 8 0 000 16z" />
  </svg>
  <input 
    placeholder="Search for Medicines and Health Products"
    class="h-[2.25rem] w-full bg-gray-300 text-black pl-8 pr-2 rounded-md" />
</div>


<!-- Cart Button -->
<a href="cart.html" class="w-full md:w-auto">
  <div class="h-[2.25rem] w-full md:w-[7rem] bg-red-700 text-white font-bold text-center flex items-center justify-center rounded-md">
    VIEW CART
  </div>
</a>
</div>



<script>
  async function getLocationOnce() {
    const input = document.getElementById("location-input");
    const clearBtn = document.getElementById("clear-btn");

    if (input.dataset.clicked === "true") return;
    input.dataset.clicked = "true";

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async function (position) {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&accept-language=en`);
          const data = await res.json();
          const addr = data.address;
          const place = addr.city || addr.town || addr.village || addr.suburb || addr.county || addr.state;

          input.value = place || "Location unavailable";
          clearBtn.classList.remove("hidden");
        } catch (err) {
          input.value = "Location error";
        }
      }, () => {
        input.value = "Permission denied";
      });
    } else {
      input.value = "Geolocation not supported";
    }
  }

  function clearLocation() {
    const input = document.getElementById("location-input");
    const clearBtn = document.getElementById("clear-btn");

    input.value = "";
    input.dataset.clicked = "false";
    clearBtn.classList.add("hidden");
  }
</script>


     
    
       
  
       <div class="h-[3rem] w-full z-10 bg-white flex items-center px-4 flex-wrap justify-between md:gap-16">
         
         <!-- Health Center -->
         <div class="relative group" onmouseenter="showMenu('health-center-menu')" onmouseleave="hideMenu('health-center-menu')">
           <div class="h-[3rem] w-[12rem] text-black font-semibold flex items-center justify-center cursor-pointer hover:bg-gray-200">
             <span>Health Center ⌵</span>
           </div>
           <div id="health-center-menu" class="absolute hidden bg-white shadow-lg w-[12rem] rounded-md z-20">
             <ul class="py-2">
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('All Diseases')">All Diseases</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('All Medicines')">All Medicines</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('General Care')">General Care</li>
             </ul>
           </div>
         </div>
     
         <!-- Nutritional Drinks -->
         <div class="relative group" onmouseenter="showMenu('nutritional-drinks-menu')" onmouseleave="hideMenu('nutritional-drinks-menu')">
           <div class="h-[3rem] w-[12rem] text-black font-semibold flex items-center justify-center cursor-pointer hover:bg-gray-200">
             <span>Nutritional Drinks ⌵</span>
           </div>
           <div id="nutritional-drinks-menu" class="absolute hidden bg-white shadow-lg w-[12rem] rounded-md z-20">
             <ul class="py-2">
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Protein Shakes')">Protein Shakes</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Energy Boosters')">Energy Boosters</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Kids Nutrition')">Kids Nutrition (2-15 Yrs)</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Green Coffee')">Green Coffee</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Diabetes Nutrition')">Diabetes Nutrition</li>
             </ul>
           </div>
         </div>
     
         <!-- Stomach Care -->
         <div class="relative group" onmouseenter="showMenu('stomach-care-menu')" onmouseleave="hideMenu('stomach-care-menu')">
           <div class="h-[3rem] w-[11rem] text-black font-semibold flex items-center justify-center cursor-pointer hover:bg-gray-200">
             <span>Stomach Care ⌵</span>
           </div>
           <div id="stomach-care-menu" class="absolute hidden bg-white shadow-lg w-[11rem] rounded-md z-20">
             <ul class="py-2">
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Acidity')">Acidity</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Gas Relief')">Gas Relief</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Diarrhoea')">Diarrhoea</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Bloating')">Bloating</li>
             </ul>
           </div>
         </div>
     
         <!-- Pain Relief -->
         <div class="relative group" onmouseenter="showMenu('pain-relief-menu')" onmouseleave="hideMenu('pain-relief-menu')">
           <div class="h-[3rem] w-[11rem] text-black font-semibold flex items-center justify-center cursor-pointer hover:bg-gray-200">
             <span>Pain Relief ⌵</span>
           </div>
           <div id="pain-relief-menu" class="absolute hidden bg-white shadow-lg w-[11rem] rounded-md z-20">
             <ul class="py-2">
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Pain Relief Tablets')">Pain Relief Tablets</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Pain Balm')">Pain Balm</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Oils For Pain Relief')">Oils For Pain Relief</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Gel & Sprays')">Gel & Sprays</li>
             </ul>
           </div>
         </div>
     
         <!-- Healthy Snacks -->
         <div class="relative group" onmouseenter="showMenu('healthy-snacks-menu')" onmouseleave="hideMenu('healthy-snacks-menu')">
           <div class="h-[3rem] w-[11rem] text-black font-semibold flex items-center justify-center cursor-pointer hover:bg-gray-200">
             <span>Healthy Snacks ⌵</span>
           </div>
           <div id="healthy-snacks-menu" class="absolute hidden bg-white shadow-lg w-[11rem] rounded-md z-20">
             <ul class="py-2">
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Oats')">Oats</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Dry Fruits')">Dry Fruits</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Superfoods')">Superfoods</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Muesli & Cereals')">Muesli & Cereals</li>
             </ul>
           </div>
         </div>
     
         <!-- Vitamins & Nutrition -->
         <div class="relative group" onmouseenter="showMenu('feminine-care-menu')" onmouseleave="hideMenu('feminine-care-menu')">
           <div class="h-[3rem] w-[11rem] text-black font-semibold flex items-center justify-center cursor-pointer hover:bg-gray-200">
             <span>Vitamins & Nutrition ⌵</span>
           </div>
           <div id="feminine-care-menu" class="absolute hidden bg-white shadow-lg w-[11rem] rounded-md z-20">
             <ul class="py-2">
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Vitamin D')">Vitamin D</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Vitamin C')">Vitamin C</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Vitamin A')">Vitamin A</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Vitamin K')">Vitamin K</li>
               <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="goTo('Gummies Vitamins')">Gummies Vitamins</li>
             </ul>
           </div>
         </div>
       </div>
     
       <!-- JavaScript -->
       <script>
         function showMenu(id) {
           document.getElementById(id).classList.remove('hidden');
         }
     
         function hideMenu(id) {
           document.getElementById(id).classList.add('hidden');
         }
     
         function goTo(category) {
           const encoded = encodeURIComponent(category.trim());
           window.location.href = `category.html?name=${encoded}`;
         }
       </script>
   
          
     
     

<!-- Image Slider -->
<div class="relative h-[22rem] w-full z-2  max-w-screen-lg mx-auto overflow-hidden mt-5">
   <div id="posterContainer" class="flex w-[300%] h-full transition-transform duration-1000 ease-linear">
       <img src="poster.jpg" alt="Poster" class="w-1/3 h-full object-cover">
       <img src="poster3.jpg" alt="Poster" class="w-1/3 h-full object-cover">
       <img src="poster1.jpg" alt="Poster" class="w-1/3 h-full object-cover">
   </div>
</div>

<!-- JavaScript -->
<script>
   // Dropdown Menu Handling
  

   // Image Slider Handling
   const posters = document.getElementById("posterContainer");
   let index = 0;
   const totalImages = 3;

   function changePoster() {
       index++;
       
       // When reaching the last image, reset instantly after transition
       if (index === totalImages) {
           setTimeout(() => {
               posters.style.transition = "none"; // Remove animation for instant reset
               posters.style.transform = `translateX(0%)`; // Reset to first image
               index = 0;
           }, 1000); // Wait for transition before resetting
       }

       // Move to the next image
       posters.style.transition = "transform 1s ease-in-out"; // Smooth slide
       posters.style.transform = `translateX(-${index * 100 / totalImages}%)`;
   }

   setInterval(changePoster, 3000); // Change every 5 seconds
</script>




<div class="h-[2.5rem] w-full  mt-5 flex border-0 gap-3 px-5 sm:px-10">
   <div class="h-[2rem] text-black font-bold flex items-center">
       <a href="">Feature Brands</a>
   </div>
</div>

<div class="h-auto w-full flex flex-wrap justify-center gap-6 shadow bg-white mt-4 border-0 p-4">
   <a href="himalaya.html">
       <div class="h-[10rem] w-[10rem] sm:h-[13rem] sm:w-[13rem] shadow shadow-gray-300 border-2 rounded-full bg-[url(himalaya.jpg)] bg-center bg-cover">
       </div>
   </a>
   <a href="dabur.html">
       <div class="h-[10rem] w-[10rem] sm:h-[13rem] sm:w-[13rem] shadow shadow-gray-300 border-2 rounded-full bg-[url(https://static.wixstatic.com/media/4755b5_fbcb1559b39e4087be16cec7d0f998e7~mv2.png/v1/fit/w_500,h_500,q_90/file.png)] bg-cover bg-center">
       </div>
   </a>
   <a href="mb.html">
       <div class="h-[10rem] w-[10rem] sm:h-[13rem] sm:w-[13rem] shadow shadow-gray-300 border-2 rounded-full bg-[url(d1.jpg)] bg-cover bg-center">
       </div>
   </a>
   <a href="dettol.html">
       <div class="h-[10rem] w-[10rem] sm:h-[13rem] sm:w-[13rem] shadow shadow-gray-300 border-2 rounded-full bg-[url(dettol.jpg)] bg-cover bg-center">
       </div>
   </a>
   <a href="Cetaphil.html">
       <div class="h-[10rem] w-[10rem] sm:h-[13rem] sm:w-[13rem] shadow shadow-gray-300 border-2 rounded-full bg-[url(d6.jpg)] bg-cover bg-center">
       </div>
   </a>
</div>
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold "><a href="">Winter care</a></div>
      </div>



      <div class="h-[30rem] w-[80rem] flex gap-0 shadow shadow-gray-300 mt-4 border-0 bg-white ">
         <a href="product-details.html?name=Himalaya Winter Defense&desc=Moisturizing Cream(100ml)&mrp=175.00&discount=15&price=149.00&img=https://m.media-amazon.com/images/I/61j1Y5h6hEL._SL1024_.jpg" >
            
         <div
            class="h-[28rem] w-[14rem]     mt-4  ml-[5rem]   rounded-t-md rounded-b-md   hover:shadow hover:shadow-gray-400">


            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm   bg-[url(https://m.media-amazon.com/images/I/61j1Y5h6hEL._SL1024_.jpg)] bg-cover flex">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Himalaya Winter Defense</p>
               <p>Moisturizing Cream(100ml)</p>

               <p class=" mt-[4.5rem] flex gap-2.5 ml-2 Green">MRP<s>₹175.00</s>15% off</p>
               <p class="font-bold ml-2">₹149.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Nivea Soft Light Defense&desc=Moisturising Cream(100 ml)&mrp=360.00&discount=1&price=359.00&img=https://cdn.tirabeauty.com/v2/billowing-snowflake-434234/tira-p/wrkr/products/pictures/item/free/original/1018244/bTG8nxMH0F-1018244-1.jpg" >
            
         <div
            class="h-[28rem] w-[14rem]      mt-4    rounded-t-md rounded-b-md  hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://cdn.tirabeauty.com/v2/billowing-snowflake-434234/tira-p/wrkr/products/pictures/item/free/original/1018244/bTG8nxMH0F-1018244-1.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Nivea Soft Light</p>
               <p>Moisturising Cream(100 ml)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 ml-2 Green">MRP<s>₹360.00</s>1% off</p>
               <p class="font-bold ml-2">₹359.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Joy honey & almonds Defense&desc=nourishing cream(100 ml)&mrp=499.00&discount=30&price=349.00&img=https://5.imimg.com/data5/ECOM/Default/2024/5/422115514/LY/BO/ME/44622788/1661422285697-joyalm-1000x1000.jpeg" >
         <div
            class="h-[28rem] w-[14rem]   mt-4    rounded-t-md rounded-b-md  hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem] ml-5  mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://5.imimg.com/data5/ECOM/Default/2024/5/422115514/LY/BO/ME/44622788/1661422285697-joyalm-1000x1000.jpeg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p> Joy honey & almonds</p>
               <p> nourishing cream(100 ml)</p>
               <p class=" mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹499.00</s>30% off</p>
               <p class="font-bold ml-2">₹349.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=St.Botanica Bulgarian Rose&desc=Otto Glow Day Cream(50 g)&mrp=899.00&discount=42&price=519.00&img=https://files.stbotanica.com/site-images/800x800/STBOT685-2.jpg" >
         <div
            class="h-[28rem] w-[14rem]     mt-4    rounded-t-md rounded-b-md hover:shadow hover:shadow-gray-400   ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://files.stbotanica.com/site-images/800x800/STBOT685-2.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>St.Botanica Bulgarian Rose</p>
               <p>Otto Glow Day Cream(50 g)</p>
               <p class=" mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹899.00</s>42% off</p>
               <p class="font-bold ml-2">₹519.00</p>
               <div class="h-[3.5rem] w-[13rem]   bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Cetaphil Ultra Hydrating &desc=Lotion For Dry Skin(30 g)&mrp=260.00&discount=8&price=239.00&img=https://cdn01.pharmeasy.in/dam/products_otc/038119/cetaphil-dam-daily-advance-ultra-hydrating-lotion-30g-3-1618427034.jpg" >
         <div
            class="h-[28rem] w-[14rem]   mt-4 border-0  rounded-t-md rounded-b-md hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://cdn01.pharmeasy.in/dam/products_otc/038119/cetaphil-dam-daily-advance-ultra-hydrating-lotion-30g-3-1618427034.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Cetaphil Ultra Hydrating </p>
               <p>Lotion For Dry Skin(30 g)</p>
               <p class=" mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹260.00</s>8% off</p>
               <p class="font-bold ml-2">₹239.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div>
      </div></a>
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold"><a href="">Eye care</a></div>
      </div>
      <div class="h-[30rem] w-[80rem]  flex gap-0 shadow bg-white shadow-gray-300 mt-4 border-0 ">
         <a href="product-details.html?name=ALLEN A12 Eye Care Drops &desc=(2 x 30 ml)&mrp=390.00&discount=7&price=360.00&img=https://homeobasket.com/wp-content/uploads/2023/05/A12-1.jpg" >
         <div
            class="h-[28rem] w-[14rem]      mt-4  ml-[5rem] bg-center  rounded-t-md rounded-b-md hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  bg-[url(https://homeobasket.com/wp-content/uploads/2023/05/A12-1.jpg)] bg-cover  flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>ALLEN A12 Eye Care Drops <br>  (2 x 30 ml)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green m-2">MRP<s>₹390.00</s>7% off</p>
               <p class="font-bold ml-2 -mt-2">₹360.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Eyecrique Essential Eye Care  &desc=Supplement for Healthy&mrp=699.00&discount=24&price=529.00&img=https://m.media-amazon.com/images/I/81Mp6PMCgnL.jpg" >
         <div
            class="h-[28rem] w-[14rem]   mt-4 border-0   rounded-t-md rounded-b-md hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/81Mp6PMCgnL.jpg)] bg-cover flex">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>Eyecrique Essential Eye Care </p>
               <p>Supplement for Healthy</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹699.00</s>24% off</p>
               <p class="font-bold ml-2">₹529.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Healthyr-U Eye & vision care  &desc=Tablets&mrp=949.00&discount=4&price=902.00&img=https://m.media-amazon.com/images/I/61qNna1mfxL._SL1200_.jpg" >
         <div
            class="h-[28rem] w-[14rem]   mt-4 border-0   rounded-t-md rounded-b-md hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/61qNna1mfxL._SL1200_.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Healthyr-U Eye & vision care</p>
               <p>Tablets</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹949.00</s>4% off</p>
               <p class="font-bold ml-2">₹902.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Enhance Eye Health with ii&desc=Care Daily Capsules&mrp=1100.00&discount=10&price=999.00&img=https://www.assetpharmacy.com/wp-content/uploads/2022/03/iiCare-Capsules-Eye-Supplement-30-Softgel-Capsules-1-1024x1024.jpg" >
         <div
            class="h-[28rem] w-[14rem]      mt-4 border-0   rounded-t-md rounded-b-md hover:shadow hover:shadow-gray-400 ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.assetpharmacy.com/wp-content/uploads/2022/03/iiCare-Capsules-Eye-Supplement-30-Softgel-Capsules-1-1024x1024.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>Enhance Eye Health with ii</p>
               <p>Care Daily Capsules</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹1100.00</s class="Green ">10% off</p>
               <p class="font-bold ml-2">₹999.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Fit Eye Tablet with Vitamins&desc=Resveratrol,Bilberry Extracts&mrp=300.00&discount=10&price=279.00&img=https://th.bing.com/th/id/OIP.0sg4pRoRtF26BgNoduJwrAHaHa?w=600&h=600&rs=1&pid=ImgDetMain" >
         <div
            class="h-[28rem] w-[14rem]  mt-4 border-0  rounded-t-md rounded-b-md  hover:shadow hover:shadow-gray-400">
            <div
               class="h-[11.5rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://th.bing.com/th/id/OIP.0sg4pRoRtF26BgNoduJwrAHaHa?w=600&h=600&rs=1&pid=ImgDetMain)] bg-cover flex">
            </div>
            <div
               class=" mt-2 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Fit Eye Tablet with Vitamins,</p>
               <p>Resveratrol&Bilberry Extracts</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹300.00</s>10% off</p>
               <p class="font-bold ml-2">₹279.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
      </div>
      <div class="h-[20rem] w-full shadow-2xl shadow-gray-300 mt-4 border-0 relative">
         <img src="poster1.jpg" alt="Promotional Poster" class="w-full h-full object-cover">
      </div>
      
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold"><a href="">Oral care</a></div>
      </div>
      <div class="h-[30rem] w-[80rem]  flex gap-0 shadow shadow-gray-300 mt-4 border-0  bg-white">
         <a href="product-details.html?name=PLANTPICK Ayurvedic Oral&desc=Care Mouthwash(15 ml)&mrp=800.00&discount=6&price=749.00&img=https://m.media-amazon.com/images/I/81k8BupB7wL._SX679_.jpg" >
         <div
            class="h-[28rem] w-[14rem]    hover:shadow hover:shadow-gray-400 mt-4 border-0 ml-[5rem]  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/81k8BupB7wL._SX679_.jpg)] bg-cover flex ">
         </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>PLANTPICK Ayurvedic Oral</p>
               <p>Care Mouthwash(15 ml)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹800.00</s>6% off</p>
               <p class="font-bold ml-2">₹749.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Herb'l Tulsi-Anti Bacterial&desc=Toothpaste(600g pack of 3)&mrp=330.00&discount=10&price=299.00&img=https://m.media-amazon.com/images/I/81ysOIjEYAL.jpg" >
         <div
            class="h-[28rem] w-[14rem]  ml-5 mt-4 hover:shadow hover:shadow-gray-400 border-0   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/81ysOIjEYAL.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>Herb'l Tulsi-Anti Bacterial</p>
               <p>Toothpaste(600g pack of 3)</p>
               <p class=" mt-[4.5rem] flex gap-2.5  Green ml-2">MRP<s>₹330.00</s>10% off</p>
               <p class="font-bold ml-2">₹299.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Listerine Antiseptic&desc=MouthwashCool Mint&mrp=220.00&discount=20&price=199.00&img=https://m.media-amazon.com/images/I/71njvndq+PL.jpg" >
         <div
            class="h-[28rem] w-[14rem]    hover:shadow hover:shadow-gray-400 mt-4 border-0   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/71njvndq+PL.jpg)] bg-cover  bg-center flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>Listerine Antiseptic </p>
               <p> MouthwashCool Mint</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹220.00</s>20% off</p>
               <p class="font-bold ml-2">₹199.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Amulya Oral Care&desc=Drops-25ml&mrp=199.00&discount=5&price=179.00&img=https://5.imimg.com/data5/VB/IN/MY-29405264/oral-care-500x500.jpg" >
         
         <div
            class="h-[28rem] w-[14rem]   hover:shadow hover:shadow-gray-400  mt-4 border-0   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem] ml-5 mt-4   rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://5.imimg.com/data5/VB/IN/MY-29405264/oral-care-500x500.jpg)] bg-cover flex">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Amulya Oral Care</p>
               <p>Drops-25ml</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹199.00</s>5% off</p>
               <p class="font-bold ml-2">₹179.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Eternal Life Ayurveda&desc=Oral Heal Oil(10 ml)&mrp=149.00&discount=10&price=134.00&img=https://m.media-amazon.com/images/I/51aogr2YDFL._AC_UF1000,1000_QL80_.jpg" >
         <div
            class="h-[28rem] w-[14rem]     hover:shadow hover:shadow-gray-400 mt-4 border-0   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/51aogr2YDFL._AC_UF1000,1000_QL80_.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>Eternal Life Ayurveda</p>
               <p>Oral Heal Oil(10 ml)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹149.00</s>10% off</p>
               <p class="font-bold ml-2">₹134.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div>
      </div></a>
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold "><a href="">Knee care</a></div>
      </div>
      <div class="h-[30rem]  w-[80rem]  flex gap-0 shadow shadow-gray-300 mt-4   bg-white">
         <a href="product-details.html?name=Arthritis Care Knee&desc=Support|Actimove&mrp=435.00&discount=53&price=203.00&img=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHILHFa3mJOSGC76VO6a1LYu-seMUcjYXlEw&s" >
         <div
            class="h-[28rem] w-[14rem]     hover:shadow hover:shadow-gray-400 mt-4 ml-[5rem]  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  bg-[url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHILHFa3mJOSGC76VO6a1LYu-seMUcjYXlEw&s)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Arthritis Care Knee</p>
               <p>Support|Actimove</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹435.00</s>53% off</p>
               <p class="font-bold ml-2">₹203.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Chandigarh Ayurved Center&desc=knee Care Tablet(100-Tablets)&mrp=1000.00&discount=10&price=899.00&img=https://www.chandigarhayurvedcentre.com/wp-content/uploads/2020/07/knee-care-tablet.png" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400 mt-4  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.chandigarhayurvedcentre.com/wp-content/uploads/2020/07/knee-care-tablet.png)] bg-cover bg-cente flex ">
            </div>
            <div
               class=" mt-4 ml-2 h-[7.5rem] w-[13rem] ">
               <p>Chandigarh Ayurved Center</p>
               <p>knee Care Tablet(100-Tablets)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹1000.00</s>10% off</p>
               <p class="font-bold ml-2">₹899.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Knee Care Tablets&desc=10x10,Prescription&mrp=240.00&discount=10&price=219.00&img=https://5.imimg.com/data5/SELLER/Default/2023/1/SL/WO/JA/9193360/knee-joint-forte-1000x1000.jpg" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400  mt-4   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://5.imimg.com/data5/SELLER/Default/2023/1/SL/WO/JA/9193360/knee-joint-forte-1000x1000.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2  h-[7.5rem] w-[13rem]">
               <p>Knee Care Tablets</p>
               <p>10x10,Prescription</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹240.00</s>10% off</p>
               <p class="font-bold ml-2">₹219.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=RIDOMAXX Ortho&desc=Knee Tablets&mrp=390.00&discount=16&price=328.00&img=https://www.ridomaxx.com/wp-content/uploads/2024/02/Ridomaxx-K-C-Slide-1.jpg" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400 mt-4  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.ridomaxx.com/wp-content/uploads/2024/02/Ridomaxx-K-C-Slide-1.jpg)] bg-cover flex">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>RIDOMAXX Ortho</p>
               <p>Knee Tablets</p>
               <p class="mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹390.00</s>16% off</p>
               <p class="font-bold ml-2">₹328.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=LivEasy Ortho Care&desc=Knee cap&mrp=399.00&discount=26&price=295.00&img=https://rukminim2.flixcart.com/image/850/1000/kgwld3k0/support/d/g/m/na-ortho-care-knee-cap-m-s85769-42-5-liveasy-48-75-original-imafxfkyhxa5decs.jpeg?q=90&crop=false" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400 mt-4   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://rukminim2.flixcart.com/image/850/1000/kgwld3k0/support/d/g/m/na-ortho-care-knee-cap-m-s85769-42-5-liveasy-48-75-original-imafxfkyhxa5decs.jpeg?q=90&crop=false)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>LivEasy Ortho Care</p>
               <p>Knee cap</p>
               
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹399.00</s>26% off</p>
               <p class="font-bold ml-2">₹295.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div>
      </div></a>
      
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold"><a href="">Liver care</a></div>
      </div>
      <div class="h-[30rem] w-[80rem]  flex gap-0 shadow shadow-gray-300 mt-4 bg-white ">
         <a href="product-details.html?name=Herbal Plant Based Liver Care&desc=Boosts Metabolism (6 0ml)&mrp=825.00&discount=27&price=599.00&img=https://m.media-amazon.com/images/I/519lIOqk3IL.jpg" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400  mt-4 border-0 ml-[5rem]  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/519lIOqk3IL.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Herbal Plant Based Liver Care</p>
                  <p>Boosts Metabolism (6 0ml)</p>
                  <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹825.00</s>27% off</p>
                  <p class="font-bold ml-2">₹599.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=HealthAid Livercare&desc=supplement with Milk Thistle&mrp=1,460.00&discount=19&price=1,186.00&img=https://www.pharmacoline.com/product/healthaid-livercare-60-tablets/products-livercare-health-aid.jpg" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400    mt-4   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem] ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.pharmacoline.com/product/healthaid-livercare-60-tablets/products-livercare-health-aid.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>HealthAid Livercare</p>
                  <p>supplement with Milk Thistle</p>
                  <p class="mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹1,460.00</s>19% off</p>
                  <p class="font-bold ml-2">₹1,186.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Himalaya Liver Care,Pack of&desc=180 Capsules&mrp=10,000.00&discount=31&price=6,873.00&img=https://s3.images-iherb.com/him/him00511/l/20.jpg" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400  mt-4   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://s3.images-iherb.com/him/him00511/l/20.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Himalaya Liver Care,Pack of</p> 
                  <p>180 Capsules</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹10,000.00</s>31% off</p>
                  <p class="font-bold ml-2">₹6,873.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Kapiva Liver Care Juice|Anti-&desc=oxidant Rich Supplement(1L)&mrp=769.00&discount=10&price=699.00&img=https://m.media-amazon.com/images/I/51AyZ0b9rTS._SL1080_.jpg" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400  mt-4 border-0  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/51AyZ0b9rTS._SL1080_.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Kapiva Liver Care Juice|Anti- </p>
                  <p>oxidant Rich Supplement(1L)</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹769.00</s>10% off</p>
                  <p class="font-bold ml-2">₹699.00</p><div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Herbs of Gold St Mary's &desc=Thistle 35000 60Tablets&mrp=9,000.00&discount=10&price=8,999.00&img=https://www.vimandco.com.au/wp-content/uploads/2020/04/Herbs-of-Gold-St-Marys-Thistle-35000-60-Tabs_resized.png" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400   mt-4 border-0   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.vimandco.com.au/wp-content/uploads/2020/04/Herbs-of-Gold-St-Marys-Thistle-35000-60-Tabs_resized.png)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Herbs of Gold St Mary's </p>
                  <p>Thistle 35000 60Tablets</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹9,000.00</s>10% off</p>
                  <p class="font-bold ml-2">₹8,999.00</p><div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div>
      </div></a>
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold"><a href="">Stomach care</a></div>
      </div>
      <div class="h-[30rem] w-[80rem]  bg-white flex gap-0 shadow shadow-gray-300 mt-4 border-0 ">
         <a href="product-details.html?name=Digene Antacid Antigas Gel&desc=Heartburn & Stomach Care&mrp=278.00&discount=12&price=425.00&img=https://5.imimg.com/data5/SELLER/Default/2024/8/442952260/TH/ZS/PH/227337756/digene-bottle-of-200-ml-gel-500x500.jpg" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400  mt-4 border-0 ml-[5rem]  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://5.imimg.com/data5/SELLER/Default/2024/8/442952260/TH/ZS/PH/227337756/digene-bottle-of-200-ml-gel-500x500.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem]">
               <p>Digene Antacid Antigas Gel</p>
                  <p>Heartburn & Stomach Care</p>
                  <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹278.00</s>12% off</p>
                  <p class="font-bold ml-2">₹245.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Bio India Complex 46&desc=Backache Drop&mrp=170.00&discount=12&price=149.00&img=https://www.netmeds.com/images/product-v1/600x600/909144/bio_indias_backache_drops_46_30_ml_0_0.jpg" >
         <div
            class="h-[28rem] w-[14rem]     mt-4 border-0 hover:shadow hover:shadow-gray-400  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.netmeds.com/images/product-v1/600x600/909144/bio_indias_backache_drops_46_30_ml_0_0.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Bio India Complex 46 </p>
                  <p>Backache Drop</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹170.00</s>12% off</p>
                  <p class="font-bold ml-2">₹149.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Polycrol Xpress Relief&desc=Antacid Antigas Gel&mrp=165.00&discount=16&price=139.00&img=https://m.media-amazon.com/images/I/61Erxp82vsL.jpg" >
         <div
            class="h-[28rem] w-[14rem]    mt-4 border-0 hover:shadow hover:shadow-gray-400 rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/61Erxp82vsL.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Polycrol Xpress Relief </p>
                  <p>Antacid Antigas Gel</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹165.00</s>16% off</p>
                  <p class="font-bold ml-2">₹139.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Cremaffin Constipation Relief&desc=with Liquid Paraffin&mrp=372.00&discount=6&price=351.00&img=https://m.media-amazon.com/images/I/71HCE2QuPuL._SL1500_.jpg" >
         <div
            class="h-[28rem] w-[14rem]  mt-4 border-0 hover:shadow hover:shadow-gray-400 rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/71HCE2QuPuL._SL1500_.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Cremaffin Constipation Relief </p>
                  <p>with Liquid Paraffin</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹372.00</s>6% off</p>
                  <p class="font-bold ml-2">₹351.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Gastric Care syrup, Packaging&desc= Type: Bottle, 500 ml&mrp=110.00&discount=10&price=99.00&img=https://m.media-amazon.com/images/I/71q68zzqaFL.jpg" >
         <div
            class="h-[28rem] w-[14rem]      mt-4 border-0 hover:shadow hover:shadow-gray-400  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/71q68zzqaFL.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Gastric Care syrup, Packaging</p>
                  <p> Type: Bottle, 500 ml</p>
                  <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹110.00</s>10% off</p>
                  <p class="font-bold ml-2">₹99.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>
            </div>
         </div>
      </div></a>
      
      <div class="h-[20rem] w-full flex flex-col md:flex-row gap-4 md:gap-10  mt-4 border-0 
      bg-[url('newone2.jpg')] bg-cover bg-center">
     <img src="newone2.jpg" alt="Banner" class="w-full md:w-1/2 h-full object-cover">
     </div>

<div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold"><a href="">Respiratory care</a></div>
      </div>
      <div class="h-[30rem] w-[80rem]  bg-white flex gap-0 shadow shadow-gray-300 mt-4 border-0 ">
         <a href="product-details.html?name=Iafa Respiratory Care X Drop&desc=Iafa Ayurveda India&mrp=290.00&discount=8&price=267.00&img=https://onemg.gumlet.io/l_watermark_346,w_690,h_700/a_ignore,w_690,h_700,c_pad,q_auto,f_auto/dw29owf6beqnnudxg8gn.jpg" >
         <div
            class="h-[28rem] w-[14rem]   hover:shadow hover:shadow-gray-400 mt-4 border-0 ml-[5rem]  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://onemg.gumlet.io/l_watermark_346,w_690,h_700/a_ignore,w_690,h_700,c_pad,q_auto,f_auto/dw29owf6beqnnudxg8gn.jpg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Iafa Respiratory Care X Drop</p>
                  <p>Iafa Ayurveda India</p>
                  <p class="mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹290.00</s>8% off</p>
                  <p class="font-bold ml-2">₹267.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>  
            </div>
         </div></a>
         <a href="product-details.html?name=Ayubal Wellness Heart Care &desc=Powder Non prescription&mrp=699.00&discount=10&price=599.00&img=https://5.imimg.com/data5/SELLER/Default/2023/10/355265642/WR/UJ/HQ/87959796/heart-care-powder.png" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400 mt-4   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm   bg-[url(https://5.imimg.com/data5/SELLER/Default/2023/10/355265642/WR/UJ/HQ/87959796/heart-care-powder.png)] bg-center bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Ayubal Wellness Heart Care </p>
               <p>Powder Non prescription</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹699.00</s>10% off</p>
               <p class="font-bold ml-2">₹599.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Cold ,Cough Wll&desc=Pills (30G)&mrp=169.00&discount=10&price=149.00&img=https://m.media-amazon.com/images/I/61JPzOn-TPL._SL1001_.jpg" >
         <div
            class="h-[28rem] w-[14rem]  mt-4 hover:shadow hover:shadow-gray-400  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://m.media-amazon.com/images/I/61JPzOn-TPL._SL1001_.jpg)] bg-cover bg-current flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Cold & Cough Wll</p>
               <p>Pills (30G)</p>
               <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹169.00</s>10% off</p>
               <p class="font-bold ml-2">₹149.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Real Relief Asthma &desc=Respiratory Care Nighttime&mrp=10,000.00&discount=10&price=8,999.00&img=https://5.imimg.com/data5/SELLER/Default/2024/1/379613023/CG/SO/ET/209259855/whatsapp-image-2024-01-22-at-23-05-31-1-500x500.jpeg" >
         <div
            class="h-[28rem] w-[14rem]  mt-4 border-0 hover:shadow hover:shadow-gray-400 rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-0 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://5.imimg.com/data5/SELLER/Default/2024/1/379613023/CG/SO/ET/209259855/whatsapp-image-2024-01-22-at-23-05-31-1-500x500.jpeg)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Real Relief Asthma </p>
                  <p>Respiratory Care Nighttime </p>
                  <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹10,000.00</s>10% off</p>
                  <p class="font-bold ml-2">₹8,999.00</p>
                  <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                     <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
                  </div>  
            </div>
         </div></a>
         <a href="product-details.html?name=AZYN TABLETS&desc=Azithromycin-RTI(250 mg)&mrp=1,100.00&discount=10&price=999.00&img=https://5.imimg.com/data5/SELLER/Default/2021/6/IC/HB/KU/844634/ag-250-mg-azithromycin-tablets-500x500.png" >
         <div
            class="h-[28rem] w-[14rem]     hover:shadow hover:shadow-gray-400 mt-4 border-0   rounded-t-md rounded-b-md  ">          <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://5.imimg.com/data5/SELLER/Default/2021/6/IC/HB/KU/844634/ag-250-mg-azithromycin-tablets-500x500.png)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>AZYN TABLETS</p>
               <p>Azithromycin-RTI(250 mg)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹1,100.00</s>10% off</p>
               <p class="font-bold ml-2">₹999.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div>
      </div></a>
      <div class="h-[2.5rem] w-full  mt-5 flex border-0  gap-3 ">
         <div class=" h-[2rem] w-[9rem]  mt-0.5 ml-[5rem]  text-black font-bold"><a href="">Diabeties</a></div>
      </div>
      <div class="h-[30rem] w-[80rem]  flex gap-0 bg-white shadow shadow-gray-300 mt-4 border-0 ">
         <a href="product-details.html?name=Diabetes Neuropathy&desc=Medicine&mrp=380.00&discount=20&price=149.00&img=https://th.bing.com/th/id/OIP.-6Sba9eihhs75RiWMqJ2egHaHa?rs=1&pid=ImgDetMain" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400 mt-4 border-0 ml-[5rem]  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://th.bing.com/th/id/OIP.-6Sba9eihhs75RiWMqJ2egHaHa?rs=1&pid=ImgDetMain)] bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Diabetes Neuropathy</p>
               <p>Medicine</p>
               <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹380.00</s>20% off</p>
               <p class="font-bold ml-2">₹149.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Metformin found to be safe&desc=for most diabetics&mrp=1,500.00&discount=20&price=1,399.00&img=https://cached.imagescaler.hbpl.co.uk/resize/scaleWidth/882/cached.offlinehbpl.hbpl.co.uk/news/2MM/Metformin-NDMA-contamination-prescribers-reassured-20191211035939433.jpg" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400  mt-4 border-0  rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem] ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://cached.imagescaler.hbpl.co.uk/resize/scaleWidth/882/cached.offlinehbpl.hbpl.co.uk/news/2MM/Metformin-NDMA-contamination-prescribers-reassured-20191211035939433.jpg)] bg-center bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Metformin found to be safe</p>
               <p>for most diabetics</p>
               <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹1,500.00</s>20% off</p>
               <p class="font-bold ml-2">₹1,399.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=JANUMET CP XR TABLET&desc=Sitagliptin (100mg)&mrp=1,000.00&discount=10&price=899.00&img=https://www.medicscales.com/wp-content/uploads/2024/01/Janumet-50-Mg1000-Mg.png" >
         <div
            class="h-[28rem] w-[14rem]  hover:shadow hover:shadow-gray-400 mt-4 border-0   rounded-t-md rounded-b-md  ">
            <div
               class="h-[11rem] w-[11rem]  ml-5 mt-4 rounded-b-sm rounded-t-sm  border-amber-50 bg-[url(https://www.medicscales.com/wp-content/uploads/2024/01/Janumet-50-Mg1000-Mg.png)] bg-center bg-cover flex ">
            </div>
            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>JANUMET CP XR TABLET</p>
               <p>Sitagliptin (100mg) </p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹1,000.00</s>10% off</p>
               <p class="font-bold ml-2">₹899.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=DiabaQuit Diabetes Care&desc= (180 Each)&mrp=1,500.00&discount=30&price=1,259.00&img=https://backendsatkartar.satkartar.co.in/assets/img/product/DIBAQUIT%20(2)-w.webp" >
         <div
            class="h-[28rem] w-[14rem]   mt-4 border-0 hover:shadow hover:shadow-gray-400  rounded-t-md rounded-b-md  ">
            <div class="h-[11rem] w-[11rem] ml-5 mt-4 rounded-sm border border-amber-50 bg-cover bg-center flex 
                        bg-[url('https://backendsatkartar.satkartar.co.in/assets/img/product/DIBAQUIT%20(2)-w.webp')]">
            </div>

            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>DiabaQuit Diabetes Care</p>
               <p> (180 Each)</p>
               <p class=" mt-[4.5rem] flex gap-2.5 Green ml-2">MRP<s>₹1,500.00</s>30% off</p>
               <p class="font-bold ml-2">₹1,259.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
         <a href="product-details.html?name=Diabazac tablet-best&desc=Ayurvedic Medicine&mrp=900.00&discount=5&price=890.00&img=https://elzacherbals.com/uploads/media/2024/Diabazac-Tablets.jpg" >
         <div
            class="h-[28rem] w-[14rem] hover:shadow hover:shadow-gray-400 mt-4 border-0 rounded-t-md rounded-b-md  ">
            <div class="h-[11rem] w-[11rem] ml-5 mt-4 rounded-sm border border-amber-50 bg-cover bg-center flex 
             bg-[url('https://elzacherbals.com/uploads/media/2024/Diabazac-Tablets.jpg')]">
          </div>

            <div
               class=" mt-4 ml-2 border-0 h-[7.5rem] w-[13rem] ">
               <p>Diabazac tablet-best</p>
               <p>Ayurvedic Medicine</p>
               <p class="mt-[4.5rem]  flex gap-2.5 Green ml-2">MRP<s>₹900.00</s>5% off</p>
               <p class="font-bold ml-2">₹890.00</p>
               <div class="h-[3.5rem] w-[13rem]  bg-red-600 mt-2 rounded-b-md rounded-t-md flex">
                  <h1 class="font-bold text-2xl ml-[4.5rem] mt-2.5 text-white">ADD</h1>
               </div>
            </div>
         </div></a>
      </div>
      <div id="stats" class="h-[10rem] w-full mt-10 bg-white flex justify-center gap-10">
         <div class="h-[6rem] w-auto max-w-[9rem] text-center mt-2">
             <h1 class="font-bold text-[40px] text-blue-600 counter" data-max="5" data-type="m">0m+</h1>
             <h1 class="text-[15px] text-gray-700">Visitors</h1>
         </div>
         <div class="h-[6rem] w-auto max-w-[9rem] text-center mt-2">
             <h1 class="font-bold text-[40px] text-blue-600 counter" data-max="2" data-type="m">0m+</h1>
             <h1 class="text-[15px] text-gray-700">Orders Delivered</h1>
         </div>
         <div class="h-[6rem] w-auto max-w-[9rem] text-center mt-2">
             <h1 class="font-bold text-[40px] text-blue-600 counter" data-max="100" data-type="">0+</h1>
             <h1 class="text-[15px] text-gray-700">Cities</h1>
         </div>
     </div>
    
     
     <script>
      const counters = document.querySelectorAll('.counter');
  
      counters.forEach(counter => {
          let current = 0;
          const max = +counter.dataset.max;
          const type = counter.dataset.type; // "m" or ""
          const speed = 50; // smaller = faster
  
          function updateCounter() {
              current++;
              if (current > max) current = 0;
  
              if (type === "m") {
                  counter.innerText = `${current}m+`;
              } else {
                  counter.innerText = `${current}+`;
              }
  
              setTimeout(updateCounter, speed);
          }
  
          updateCounter();
      });
  </script>
  
      
      <!-- App Download Section -->
      <div class="h-auto w-full bg-white flex flex-wrap justify-center items-center gap-5 shadow-2xl py-4 px-6">
         <p class="text-[20px]">Get the link to download App</p>
         <input placeholder="Enter Phone Number" class="h-[3rem] w-full max-w-[25rem] p-4 bg-gray-400 rounded-md">
         <button class="h-[3rem] w-[8rem] bg-red-600 text-white rounded-md hover:bg-red-700 transition">Send Link</button>
      </div>
      
      <!-- Footer Sections -->
      <div class="h-auto flex flex-wrap justify-center gap-10 w-full bg-pink-100 text-black py-10">
         <div class="w-[15rem]">
            <h1 class="font-bold text-2xl">Know us</h1>
            <ul class="mt-4 space-y-2">
               <li>About Us</li>
               <li>Contact Us</li>
               <li>Careers</li>
               <li>Press Coverage</li>
               <li>Become a Health Partner</li>
               <li>Corporate Governance</li>
            </ul>
         </div>
         <div class="w-[15rem]">
            <h1 class="font-bold text-2xl">Our Policies</h1>
            <ul class="mt-4 space-y-2">
               <li>Privacy Policy</li>
               <li>Terms and Conditions</li>
               <li>Return Policy</li>
               <li>IP Policy</li>
               <li>Grievance Redressal Policy</li>
               <li>Fake Jobs and Fraud Disclaimer</li>
            </ul>
         </div>
         <div class="w-[15rem]">
            <h1 class="font-bold text-2xl">Our Services</h1>
            <ul class="mt-4 space-y-2">
               <li>Order Medicines</li>
               <li>Book Lab Tests</li>
               <li>Consult a Doctor</li>
               <li>Ayurveda Articles</li>
               <li>Hindi Articles</li>
               <li>Care Plan</li>
            </ul>
         </div>
         <div class="w-[15rem]">
  <h1 class="font-bold text-2xl">Connect</h1>
  <div class="flex gap-4 mt-4">
    <a href="https://www.instagram.com/crucial_king_/" target="_blank" class="h-12 w-12 flex items-center justify-center bg-pink-100 rounded-full hover:scale-110 transition">
      <i class="fab fa-instagram text-pink-600 text-3xl"></i>
    </a>
    <a href="#" target="_blank" class="h-12 w-12 flex items-center justify-center bg-red-100 rounded-full hover:scale-110 transition">
      <i class="fab fa-youtube text-red-600 text-3xl"></i>
    </a>
    <a href="#" target="_blank" class="h-12 w-12 flex items-center justify-center bg-blue-100 rounded-full hover:scale-110 transition">
      <i class="fab fa-facebook text-blue-600 text-3xl"></i>
    </a>
    <a href="#" target="_blank" class="h-12 w-12 flex items-center justify-center bg-blue-100 rounded-full hover:scale-110 transition">
      <i class="fab fa-twitter text-blue-400 text-3xl"></i>
    </a>
  </div>
</div>
      </div>
      
      <!-- Divider Line -->
      <div class="h-[1px] bg-gray-400 w-full "></div>
      
      <!-- Trust Section -->
      <div class="h-auto w-full flex flex-wrap justify-center gap-10 bg-pink-100 text-black py-10">
         <div class="flex items-center gap-4">
            <div class="h-[5.5rem] w-[5.5rem] bg-[url(trust.png)] bg-cover"></div>
            <div>
               <h1 class="font-bold text-2xl">Reliable</h1>
               <p class="text-[13px] leading-relaxed">All products displayed on Medico are<br> procured from verified and licensed<br> pharmacies. All labs listed on the platform are<br> accredited.</p>
            </div>
         </div>
         <div class="flex items-center gap-4">
            <div class="h-[5rem] w-[5rem] bg-[url(cyber.png)] bg-cover"></div>
            <div>
               <h1 class="font-bold text-2xl">Secure</h1>
               <p class="text-[14px] leading-relaxed">Medico uses Secure Sockets Layer (SSL)<br> 128-bit encryption and is PCI DSS compliant.</p>
            </div>
         </div>
         <div class="flex items-center gap-4">
            <div class="h-[5rem] w-[5rem] bg-[url(money.png)] bg-cover"></div>
            <div>
               <h1 class="font-bold text-2xl">Affordable</h1>
               <p class="text-[14px] leading-relaxed">Find affordable medicine substitutes, save up <br>to 50% on health products, up to 80% off on<br> lab tests, and get free doctor consultations.</p>
            </div>
         </div>
      </div>
      
      </div>
   
</body>
</html>