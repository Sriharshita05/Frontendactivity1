<?php
include '../db.php/db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_phone = $_POST['email_phone'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email_phone = '$email_phone'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password_hash'])) {
            $_SESSION['user'] = $user;
            header("Location: ../medicoHome.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Medico</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex justify-center items-center min-h-screen bg-gray-100">
    <div class="bg-white p-8 rounded-lg shadow-lg w-[24rem]">
        <h2 class="text-2xl font-bold mb-4 text-center">Login</h2>

        <?php if (isset($error)): ?>
            <p class="text-red-500 text-sm mb-3 text-center"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST">
            <label class="block font-semibold mb-1">Email or Phone</label>
            <input type="text" name="email_phone" class="w-full border p-2 rounded-md mb-3" required>

            <label class="block font-semibold mb-1">Password</label>
            <input type="password" name="password" class="w-full border p-2 rounded-md mb-4" required>

            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-md font-semibold hover:bg-blue-700">Login</button>
        </form>

        <p class="text-sm mt-4 text-center">
            New to Medico?
            <a href="signup.php" class="text-blue-600 font-semibold hover:underline">Create an account</a>
        </p>
    </div>
</body>
</html>
